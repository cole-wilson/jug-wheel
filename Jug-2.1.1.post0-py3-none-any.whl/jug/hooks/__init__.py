# Copyright (C) 2014, Luis Pedro Coelho <luis@luispedro.org>
# vim: set ts=4 sts=4 sw=4 expandtab smartindent:
# License: MIT

from .register import jug_hook, register_hook, register_hook_once, reset_all_hooks
