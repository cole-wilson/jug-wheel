# -*- coding: utf-8 -*-


class FailingTask(Exception):
    pass
