__version__ = '2.1.1-post'
CITATION = '''\
    Coelho, L.P., (2017). Jug: Software for Parallel Reproducible Computation in
    Python. Journal of Open Research Software. 5(1), p.30.

    http://doi.org/10.5334/jors.161'''
