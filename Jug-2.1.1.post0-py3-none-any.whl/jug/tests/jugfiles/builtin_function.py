from jug import TaskGenerator
import numpy as np
array = TaskGenerator(np.array)
a8 = array(list(range(8)))
