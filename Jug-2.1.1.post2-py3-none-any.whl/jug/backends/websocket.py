from .base import base_store, base_lock

class websocket(base_store):
    def _handle(self, name, *args):
      js.console.log("_handled", name, json.dumps(args))
      print("_handled:", name, json.dumps(args))

    def __init__(self):
      js.console.log("initialized!!")
      print('initialized!')

    def dump(self, object, name):
      self._handle("dump", object, name)

    def list(self):
      self._handle("list")

    def listlocks(self):
      self._handle("listblocks")

    def can_load(self, name):
      self._handle("can_load", name)

    def load(self, name):
      self._handle("load", name)

    def remove(self, name):
      self._handle("remove", name)

    def cleanup(self, active, keeplocks=False):
      self._handle("cleanup", active, keeplocks)

    def remove_locks(self):
      self._handle("remove_locks")

    def getlock(self, name):
      self._handle("getlock", name)

    def close(self):
      self._handle("close",)

    def remove_store(jugdir):
      self._handle("remove_store", jugdir)

    def can_load(self, a):
      self._handle("hi")

    def metadata(self, t): return None
